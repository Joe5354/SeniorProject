﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SeniorProjectRazor.Models;

namespace SeniorProjectRazor.Controllers
{
    public class ParRulesController : Controller
    {
        private readonly ParDbContext _context;

        public ParRulesController(ParDbContext context)
        {
            _context = context;
        }

        // GET: ParRules
        public async Task<IActionResult> Index()
        {
            var parDbContext = _context.ParRules.Include(p => p.CreatedByUserNavigation).Include(p => p.ParItem);
            return View(await parDbContext.ToListAsync());
        }

        // GET: ParRules/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var parRule = await _context.ParRules
                .Include(p => p.CreatedByUserNavigation)
                .Include(p => p.ParItem)
                .FirstOrDefaultAsync(m => m.RuleId == id);
            if (parRule == null)
            {
                return NotFound();
            }

            return View(parRule);
        }

        // GET: ParRules/Create
        public IActionResult Create()
        {
            ViewData["CreatedByUser"] = new SelectList(_context.Users, "UserId", "UserId");
            ViewData["ParItemId"] = new SelectList(_context.Items, "ParItemId", "ParItemId");
            return View();
        }

        // POST: ParRules/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RuleId,ParItemId,RuleName,Description,ParValue,IsActive,OrderStatus,CreatedByUser,DateCreated")] ParRule parRule)
        {
            if (ModelState.IsValid)
            {
                _context.Add(parRule);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CreatedByUser"] = new SelectList(_context.Users, "UserId", "UserId", parRule.CreatedByUser);
            ViewData["ParItemId"] = new SelectList(_context.Items, "ParItemId", "ParItemId", parRule.ParItemId);
            return View(parRule);
        }

        // GET: ParRules/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var parRule = await _context.ParRules.FindAsync(id);
            if (parRule == null)
            {
                return NotFound();
            }
            ViewData["CreatedByUser"] = new SelectList(_context.Users, "UserId", "UserId", parRule.CreatedByUser);
            ViewData["ParItemId"] = new SelectList(_context.Items, "ParItemId", "ParItemId", parRule.ParItemId);
            return View(parRule);
        }

        // POST: ParRules/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("RuleId,ParItemId,RuleName,Description,ParValue,IsActive,OrderStatus,CreatedByUser,DateCreated")] ParRule parRule)
        {
            if (id != parRule.RuleId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(parRule);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ParRuleExists(parRule.RuleId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CreatedByUser"] = new SelectList(_context.Users, "UserId", "UserId", parRule.CreatedByUser);
            ViewData["ParItemId"] = new SelectList(_context.Items, "ParItemId", "ParItemId", parRule.ParItemId);
            return View(parRule);
        }

        // GET: ParRules/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var parRule = await _context.ParRules
                .Include(p => p.CreatedByUserNavigation)
                .Include(p => p.ParItem)
                .FirstOrDefaultAsync(m => m.RuleId == id);
            if (parRule == null)
            {
                return NotFound();
            }

            return View(parRule);
        }

        // POST: ParRules/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var parRule = await _context.ParRules.FindAsync(id);
            if (parRule != null)
            {
                _context.ParRules.Remove(parRule);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ParRuleExists(int id)
        {
            return _context.ParRules.Any(e => e.RuleId == id);
        }
    }
}
