﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SeniorProjectRazor.Models;

namespace SeniorProjectRazor.Controllers
{
    public class ParNotesController : Controller
    {
        private readonly ParDbContext _context;

        public ParNotesController(ParDbContext context)
        {
            _context = context;
        }

        // GET: ParNotes
        public async Task<IActionResult> Index()
        {
            var parDbContext = _context.ParNotes.Include(p => p.CreatedByUserNavigation).Include(p => p.ParItem).Include(p => p.Rule);
            return View(await parDbContext.ToListAsync());
        }

        // GET: ParNotes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var parNote = await _context.ParNotes
                .Include(p => p.CreatedByUserNavigation)
                .Include(p => p.ParItem)
                .Include(p => p.Rule)
                .FirstOrDefaultAsync(m => m.NoteId == id);
            if (parNote == null)
            {
                return NotFound();
            }

            return View(parNote);
        }

        // GET: ParNotes/Create
        public IActionResult Create()
        {
            ViewData["CreatedByUser"] = new SelectList(_context.Users, "UserId", "UserId");
            ViewData["ParItemId"] = new SelectList(_context.Items, "ParItemId", "ParItemId");
            ViewData["RuleId"] = new SelectList(_context.ParRules, "RuleId", "RuleId");
            return View();
        }

        // POST: ParNotes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("NoteId,ParItemId,RuleId,Note,CreatedByUser,DateCreated")] ParNote parNote)
        {
            if (ModelState.IsValid)
            {
                _context.Add(parNote);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CreatedByUser"] = new SelectList(_context.Users, "UserId", "UserId", parNote.CreatedByUser);
            ViewData["ParItemId"] = new SelectList(_context.Items, "ParItemId", "ParItemId", parNote.ParItemId);
            ViewData["RuleId"] = new SelectList(_context.ParRules, "RuleId", "RuleId", parNote.RuleId);
            return View(parNote);
        }

        // GET: ParNotes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var parNote = await _context.ParNotes.FindAsync(id);
            if (parNote == null)
            {
                return NotFound();
            }
            ViewData["CreatedByUser"] = new SelectList(_context.Users, "UserId", "UserId", parNote.CreatedByUser);
            ViewData["ParItemId"] = new SelectList(_context.Items, "ParItemId", "ParItemId", parNote.ParItemId);
            ViewData["RuleId"] = new SelectList(_context.ParRules, "RuleId", "RuleId", parNote.RuleId);
            return View(parNote);
        }

        // POST: ParNotes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("NoteId,ParItemId,RuleId,Note,CreatedByUser,DateCreated")] ParNote parNote)
        {
            if (id != parNote.NoteId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(parNote);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ParNoteExists(parNote.NoteId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CreatedByUser"] = new SelectList(_context.Users, "UserId", "UserId", parNote.CreatedByUser);
            ViewData["ParItemId"] = new SelectList(_context.Items, "ParItemId", "ParItemId", parNote.ParItemId);
            ViewData["RuleId"] = new SelectList(_context.ParRules, "RuleId", "RuleId", parNote.RuleId);
            return View(parNote);
        }

        // GET: ParNotes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var parNote = await _context.ParNotes
                .Include(p => p.CreatedByUserNavigation)
                .Include(p => p.ParItem)
                .Include(p => p.Rule)
                .FirstOrDefaultAsync(m => m.NoteId == id);
            if (parNote == null)
            {
                return NotFound();
            }

            return View(parNote);
        }

        // POST: ParNotes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var parNote = await _context.ParNotes.FindAsync(id);
            if (parNote != null)
            {
                _context.ParNotes.Remove(parNote);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ParNoteExists(int id)
        {
            return _context.ParNotes.Any(e => e.NoteId == id);
        }
    }
}
