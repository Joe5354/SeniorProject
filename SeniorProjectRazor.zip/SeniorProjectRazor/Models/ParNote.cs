﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace SeniorProjectRazor.Models;

public partial class ParNote
{
    [Key]
    [Column("NoteID")]
    public int NoteId { get; set; }

    [Column("ParItemID")]
    public int ParItemId { get; set; }

    [Column("RuleID")]
    public int? RuleId { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string Note { get; set; } = null!;

    public int CreatedByUser { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DateCreated { get; set; }

    [ForeignKey("CreatedByUser")]
    [InverseProperty("ParNotes")]
    public virtual User CreatedByUserNavigation { get; set; } = null!;

    [ForeignKey("ParItemId")]
    [InverseProperty("ParNotes")]
    public virtual Item ParItem { get; set; } = null!;

    [ForeignKey("RuleId")]
    [InverseProperty("ParNotes")]
    public virtual ParRule? Rule { get; set; }
}
