﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace SeniorProjectRazor.Models;

[Table("SubCategory")]
public partial class SubCategory
{
    [Key]
    [Column("SubCatID")]
    public int SubCatId { get; set; }

    [Column("CatID")]
    public int CatId { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string? SubCatName { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string? SubCatDesc { get; set; }

    [ForeignKey("CatId")]
    [InverseProperty("SubCategories")]
    public virtual Category Cat { get; set; } = null!;

    [InverseProperty("SubCat")]
    public virtual ICollection<Item> Items { get; set; } = new List<Item>();
}
