﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace SeniorProjectRazor.Models;

public partial class ParDbContext : DbContext
{
    public ParDbContext()
    {
    }

    public ParDbContext(DbContextOptions<ParDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Item> Items { get; set; }

    public virtual DbSet<ParNote> ParNotes { get; set; }

    public virtual DbSet<ParRule> ParRules { get; set; }

    public virtual DbSet<SubCategory> SubCategories { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserRole> UserRoles { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Server=(local);Database=par_db;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.CatId).HasName("PK__Category__6A1C8ADAB11EF35B");

            entity.Property(e => e.CatId).ValueGeneratedNever();
        });

        modelBuilder.Entity<Item>(entity =>
        {
            entity.HasKey(e => e.ParItemId).HasName("PK__Items__3D55B4EBF63B7BEA");

            entity.HasOne(d => d.Cat).WithMany(p => p.Items)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Items__CatID__31EC6D26");

            entity.HasOne(d => d.CurrentResponsibleUser).WithMany(p => p.Items).HasConstraintName("FK__Items__CurrentRe__33D4B598");

            entity.HasOne(d => d.SubCat).WithMany(p => p.Items).HasConstraintName("FK__Items__SubCatID__32E0915F");
        });

        modelBuilder.Entity<ParNote>(entity =>
        {
            entity.HasKey(e => e.NoteId).HasName("PK__ParNotes__EACE357FBAFDA936");

            entity.Property(e => e.DateCreated).HasDefaultValueSql("(getdate())");

            entity.HasOne(d => d.CreatedByUserNavigation).WithMany(p => p.ParNotes)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ParNotes__Create__3F466844");

            entity.HasOne(d => d.ParItem).WithMany(p => p.ParNotes)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ParNotes__ParIte__3D5E1FD2");

            entity.HasOne(d => d.Rule).WithMany(p => p.ParNotes).HasConstraintName("FK__ParNotes__RuleID__3E52440B");
        });

        modelBuilder.Entity<ParRule>(entity =>
        {
            entity.HasKey(e => e.RuleId).HasName("PK__ParRules__110458C2B24F9BB8");

            entity.Property(e => e.DateCreated).HasDefaultValueSql("(getdate())");

            entity.HasOne(d => d.CreatedByUserNavigation).WithMany(p => p.ParRules)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ParRules__Create__398D8EEE");

            entity.HasOne(d => d.ParItem).WithMany(p => p.ParRules)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ParRules__ParIte__38996AB5");
        });

        modelBuilder.Entity<SubCategory>(entity =>
        {
            entity.HasKey(e => e.SubCatId).HasName("PK__SubCateg__396379759D9A0E05");

            entity.Property(e => e.SubCatId).ValueGeneratedNever();

            entity.HasOne(d => d.Cat).WithMany(p => p.SubCategories)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__SubCatego__CatID__2E1BDC42");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__Users__1788CCACE7AA11FF");

            entity.HasOne(d => d.UserRole).WithMany(p => p.Users)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Users__UserRoleI__29572725");
        });

        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.HasKey(e => e.UserRoleId).HasName("PK__UserRole__3D978A55C32B9DF5");

            entity.Property(e => e.UserRoleId).ValueGeneratedNever();
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
