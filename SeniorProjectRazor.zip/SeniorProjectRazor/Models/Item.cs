﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace SeniorProjectRazor.Models;

public partial class Item
{
    [Key]
    [Column("ParItemID")]
    public int ParItemId { get; set; }

    [Column("ItemID")]
    public int ItemId { get; set; }

    [Column("ProductID")]
    public int ProductId { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string? SerialNumber { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string? Barcode { get; set; }

    public int? TotalCount { get; set; }

    [Column("CatID")]
    public int CatId { get; set; }

    [Column("SubCatID")]
    public int? SubCatId { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? Source1Name { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? Source1Status { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? Source2Name { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? Source2Status { get; set; }

    public bool? Serialized { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string ConditionStatus { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string WorkflowStage { get; set; } = null!;

    [Column("WorkspaceOneTrackingID")]
    public int? WorkspaceOneTrackingId { get; set; }

    [Column("CurrentResponsibleTeamID")]
    public int? CurrentResponsibleTeamId { get; set; }

    [Column("CurrentResponsibleUserID")]
    public int? CurrentResponsibleUserId { get; set; }

    [ForeignKey("CatId")]
    [InverseProperty("Items")]
    public virtual Category Cat { get; set; } = null!;

    [ForeignKey("CurrentResponsibleUserId")]
    [InverseProperty("Items")]
    public virtual User? CurrentResponsibleUser { get; set; }

    [InverseProperty("ParItem")]
    public virtual ICollection<ParNote> ParNotes { get; set; } = new List<ParNote>();

    [InverseProperty("ParItem")]
    public virtual ICollection<ParRule> ParRules { get; set; } = new List<ParRule>();

    [ForeignKey("SubCatId")]
    [InverseProperty("Items")]
    public virtual SubCategory? SubCat { get; set; }
}
