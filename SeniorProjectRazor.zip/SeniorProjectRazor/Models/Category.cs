﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace SeniorProjectRazor.Models;

[Table("Category")]
public partial class Category
{
    [Key]
    [Column("CatID")]
    public int CatId { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string? CatName { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string? CatDesc { get; set; }

    [InverseProperty("Cat")]
    public virtual ICollection<Item> Items { get; set; } = new List<Item>();

    [InverseProperty("Cat")]
    public virtual ICollection<SubCategory> SubCategories { get; set; } = new List<SubCategory>();
}
