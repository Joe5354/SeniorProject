﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace SeniorProjectRazor.Models;

[Index("RuleName", Name = "UQ__ParRules__B88BAC0E5B3D7CC5", IsUnique = true)]
public partial class ParRule
{
    [Key]
    [Column("RuleID")]
    public int RuleId { get; set; }

    [Column("ParItemID")]
    public int ParItemId { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string RuleName { get; set; } = null!;

    [StringLength(255)]
    [Unicode(false)]
    public string? Description { get; set; }

    public int ParValue { get; set; }

    public bool IsActive { get; set; }

    public bool OrderStatus { get; set; }

    public int CreatedByUser { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DateCreated { get; set; }

    [ForeignKey("CreatedByUser")]
    [InverseProperty("ParRules")]
    public virtual User CreatedByUserNavigation { get; set; } = null!;

    [ForeignKey("ParItemId")]
    [InverseProperty("ParRules")]
    public virtual Item ParItem { get; set; } = null!;

    [InverseProperty("Rule")]
    public virtual ICollection<ParNote> ParNotes { get; set; } = new List<ParNote>();
}
