﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace SeniorProjectRazor.Models;

[Index("Username", Name = "UQ__Users__536C85E4A5BB974A", IsUnique = true)]
[Index("EmployeeId", Name = "UQ__Users__7AD04FF035606167", IsUnique = true)]
[Index("Email", Name = "UQ__Users__A9D10534AF1BA532", IsUnique = true)]
public partial class User
{
    [Key]
    [Column("UserID")]
    public int UserId { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string Username { get; set; } = null!;

    [StringLength(255)]
    [Unicode(false)]
    public string FirstName { get; set; } = null!;

    [StringLength(255)]
    [Unicode(false)]
    public string LastName { get; set; } = null!;

    [StringLength(255)]
    [Unicode(false)]
    public string Email { get; set; } = null!;

    [Column("EmployeeID")]
    [StringLength(50)]
    public string? EmployeeId { get; set; }

    public bool IsActive { get; set; }

    [Column("UserRoleID")]
    public int UserRoleId { get; set; }

    [InverseProperty("CurrentResponsibleUser")]
    public virtual ICollection<Item> Items { get; set; } = new List<Item>();

    [InverseProperty("CreatedByUserNavigation")]
    public virtual ICollection<ParNote> ParNotes { get; set; } = new List<ParNote>();

    [InverseProperty("CreatedByUserNavigation")]
    public virtual ICollection<ParRule> ParRules { get; set; } = new List<ParRule>();

    [ForeignKey("UserRoleId")]
    [InverseProperty("Users")]
    public virtual UserRole UserRole { get; set; } = null!;
}
