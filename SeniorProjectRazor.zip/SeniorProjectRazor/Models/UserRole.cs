﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace SeniorProjectRazor.Models;

[Table("UserRole")]
public partial class UserRole
{
    [Key]
    [Column("UserRoleID")]
    public int UserRoleId { get; set; }

    public bool? CreateUser { get; set; }

    public bool? EditUser { get; set; }

    public bool? CreateRule { get; set; }

    public bool? EditRule { get; set; }

    public bool? CreateNote { get; set; }

    public bool? Refresh { get; set; }

    public bool? ReadData { get; set; }

    public bool? SeeAlerts { get; set; }

    public bool? GenReports { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string Description { get; set; } = null!;

    [InverseProperty("UserRole")]
    public virtual ICollection<User> Users { get; set; } = new List<User>();
}
